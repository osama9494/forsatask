<?php
session_start();
// include variable for database connection
include 'db.php';
 ?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>  Login</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="http://cdn.ckeditor.com/4.6.1/standard/ckeditor.js"></script>
  </head>
  <body>

    <nav class="navbar navbar-default">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">login</a>
        </div>
        <div id="navbar" class="collapse navbar-collapse">

        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <header id="header">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1 class="text-center"> sign in </h1>
          </div>
        </div>
      </div>
    </header>


 <?php
include 'db/db.php';
// to check if a user send a data from form or not
 if($_SERVER['REQUEST_METHOD']=='POST'){

  $email = mysqli_real_escape_string($_POST['email']);
  $password = mysqli_real_escape_string($_POST['password']);
  $sql = "SELECT email,password,id FROM user WHERE email ='$email' AND password = '$password' ";
  $query = mysqli_query($conn,$sql);
  $row = mysqli_num_rows($query);


// to check all row from data base and get the email and bassword
  while($q = mysqli_fetch_assoc($query)>0){
       echo "<div class='alert alert-success'> welcome user </div>";
// to save id for the user used a session
    $_SESSION['userid'] =   $q['id'];
// to redirect the user in index pages
    header("REFRESH:2;URL=index.php");
  
  }
  // this if to check if the loop do not return any row , let user now there is found error
 if ($q = 1) {
   echo "<div class='alert alert-danger'> please enter your email correctly </div>";
 }





    // this is end of main if(server request)
    }

    ?>
 
   





    <section id="main">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-md-offset-4">
            <form id="login" action="<?php $_SERVER['PHP_SELF'];?>" class="well" METHOD="POST">
                  <div class="form-group">
                    <label>Email Address</label>
                    <input type="text" class="form-control" name="email" placeholder="Enter Email">
                  </div>
                  <div class="form-group">
                    <label>Password</label>
                    <input type="password" class="form-control" name="password" placeholder="Password">
                  </div>

                  <input type="submit" name="login" value="login"  class="btn btn-default btn-block">
 
  
                  

               
              </form>
                           

          </div>
        </div>
      </div>
    </section>

    <footer id="footer">
      <p>login </p>
    </footer>



    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>




