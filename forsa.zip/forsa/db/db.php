<?

$conn = new mysqli('localhost','root','','forsa');
if (!$conn) {
  echo "error to connect to databse".mysqli_errno();
}

?>